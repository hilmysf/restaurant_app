import 'package:flutter/material.dart';
import 'package:restaurant_app/data/model/Restaurant.dart';
import 'package:restaurant_app/widget/menu_card_widget.dart';

class RestaurantDetailPage extends StatelessWidget {
  final Restaurant restaurant;
  static const routeName = '/restaurant_detail_page';
  bool isFood = true;

  RestaurantDetailPage({required this.restaurant});

  @override
  Widget build(BuildContext context) {
    var pageWidth = MediaQuery.of(context).size.width;
    var pageHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        body: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Hero(
          tag: restaurant.pictureId,
          child: Container(
            height: pageHeight / 3,
            width: pageWidth,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
              image: DecorationImage(
                colorFilter: ColorFilter.mode(Colors.grey, BlendMode.softLight),
                image: NetworkImage(restaurant.pictureId),
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 32,
        ),
        Flexible(
            flex: 2,
            child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      restaurant.name,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                      textAlign: TextAlign.start,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.star,
                          color: Colors.amber,
                          size: 14,
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Text(
                          restaurant.rating.toString(),
                          style: Theme.of(context).textTheme.bodyText2,
                        ),
                      ],
                    )
                  ],
                ))),
        SizedBox(
          height: 8,
        ),
        Flexible(
            flex: 2,
            child: Container(
              width: pageWidth,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Icon(
                    Icons.location_on_rounded,
                    color: Colors.red,
                    size: 14,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    '${restaurant.city} City',
                    style: Theme.of(context).textTheme.bodyText2,
                  ),
                ],
              ),
            )),
        SizedBox(
          height: 24,
        ),
        Flexible(
            flex: 1,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Description',
                style: Theme.of(context).textTheme.subtitle1,
                textAlign: TextAlign.start,
              ),
            )),
        SizedBox(
          height: 8,
        ),
        Flexible(
            flex: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                restaurant.description,
                overflow: TextOverflow.ellipsis,
                maxLines: 4,
                style: Theme.of(context).textTheme.bodyText2,
                textAlign: TextAlign.justify,
              ),
            )),
        SizedBox(
          height: 32,
        ),
        Flexible(
            flex: 1,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Foods Menu',
                style: Theme.of(context).textTheme.subtitle2,
                textAlign: TextAlign.start,
              ),
            )),
        SizedBox(
          height: 8,
        ),
        Flexible(
            flex: 3,
            child: Center(
              child: Container(
                width: pageWidth,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: restaurant.menus.foods.length,
                    itemBuilder: (context, index) {
                      return menuCardWidget(index, isFood = true);
                    }),
              ),
            )),
        SizedBox(
          height: 8,
        ),
        Flexible(
            flex: 1,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Drinks Menu',
                style: Theme.of(context).textTheme.subtitle2,
                textAlign: TextAlign.start,
              ),
            )),
        SizedBox(
          height: 8,
        ),
        Flexible(
            flex: 3,
            child: Center(
              child: Container(
                width: pageWidth,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: restaurant.menus.drinks.length,
                    itemBuilder: (context, index) {
                      return menuCardWidget(index, isFood = false);
                    }),
              ),
            )),
      ],
    ));
  }

  menuCardWidget(index, isFood) =>
      MenuCardWidget(restaurant: restaurant, index: index, isFood: isFood);
}
