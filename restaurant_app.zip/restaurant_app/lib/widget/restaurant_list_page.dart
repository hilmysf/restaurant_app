import 'package:flutter/material.dart';
import 'package:restaurant_app/data/model/Restaurant.dart';
import 'package:restaurant_app/page/restaurant_detail_page.dart';

class RestaurantListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildList(context),
    );
  }

  Widget _buildList(BuildContext context) {
    return FutureBuilder<String>(
        future: DefaultAssetBundle.of(context)
            .loadString('assets/local_restaurant.json'),
        builder: (context, snapshot) {
          final List<Restaurant> restaurants = parseRestaurants(snapshot.data);
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: restaurants.length,
                itemBuilder: (context, index) {
                  return _buildRestaurantItem(context, restaurants[index]);
                });
          } else {
            return CircularProgressIndicator();
          }
        });
  }
}

Widget _buildRestaurantItem(BuildContext context, Restaurant restaurant) {
  return GestureDetector(
    onTap: () {
      Navigator.pushNamed(context, RestaurantDetailPage.routeName,
          arguments: restaurant);
    },
    child: Container(
      height: 90,
      width: 90,
      margin: const EdgeInsets.symmetric(vertical: 8),
      // padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Row(
        children: [
          Flexible(
            flex: 4,
            child: Hero(
              tag: restaurant.pictureId,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  image: DecorationImage(
                    image: NetworkImage(restaurant.pictureId),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 16,
          ),
          Flexible(
              flex: 6,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    restaurant.name,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.start,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.location_on_rounded,
                        color: Colors.red,
                      ),
                      Text(
                        restaurant.city,
                        style: Theme.of(context).textTheme.bodyText2,
                        textAlign: TextAlign.start,
                      )
                    ],
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                      Text(
                        restaurant.rating.toString(),
                        style: Theme.of(context).textTheme.bodyText2,
                        textAlign: TextAlign.start,
                      )
                    ],
                  ),
                ],
              ))
        ],
      ),
    ),
  );
}
