import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:restaurant_app/common/styles.dart';
import 'package:restaurant_app/data/model/Restaurant.dart';

class MenuCardWidget extends StatelessWidget {
  final Restaurant restaurant;
  int index;
  bool isFood;
  double cardSize = 120.0;

  MenuCardWidget(
      {required this.restaurant, required this.index, required this.isFood});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: cardSize,
      width: cardSize,
      child: Card(
          elevation: 2,
          color: secondaryColor,
          child: Center(
            child: isFood
                ? Text(
                    restaurant.menus.foods[index].name,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.button!.apply(
                          color: Colors.white,
                        ),
                  )
                : Text(
                    restaurant.menus.drinks[index].name,
                    textAlign: TextAlign.center,
                    style: Theme.of(context)
                        .textTheme
                        .button!
                        .apply(color: Colors.white),
                  ),
          )),
    );
  }
}
