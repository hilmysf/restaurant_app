import 'dart:convert';

class Restaurant {
  late String id;
  late String name;
  late String description;
  late String pictureId;
  late String city;
  late double rating;
  late Menus menus;

  Restaurant(
      {required this.id,
      required this.name,
      required this.description,
      required this.pictureId,
      required this.city,
      required this.rating,
      required this.menus});

  Restaurant.fromJson(Map<String, dynamic> restaurant) {
    id = restaurant["id"];
    name = restaurant["name"];
    description = restaurant["description"];
    pictureId = restaurant["pictureId"];
    city = restaurant["city"];
    rating = restaurant["rating"].toDouble();
    menus = Menus.fromJson(restaurant["menus"]);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'pictureId': pictureId,
        'city': city,
        'rating': rating
      };
}

class Data {
  List<Restaurant> restaurants;

  Data({required this.restaurants});

  factory Data.fromJson(Map<String, dynamic> data) => Data(
      restaurants: List<Restaurant>.from(data['restaurants']
          .map((restaurant) => Restaurant.fromJson(restaurant))));

  Map<String, dynamic> toJson() => {
        "restaurants": List<dynamic>.from(
            restaurants.map((restaurant) => restaurant.toJson()))
      };
}

List<Restaurant> parseRestaurants(String? json) {
  if (json == null) {
    return [];
  }
  final List<Restaurant> restaurants =
      Data.fromJson(jsonDecode(json)).restaurants;
  return restaurants;
}

class Menus {
  List<Foods> foods;
  List<Drinks> drinks;

  Menus({required this.foods, required this.drinks});

  factory Menus.fromJson(Map<String, dynamic> json) => Menus(
      foods:
          List<Foods>.from(json["foods"].map((food) => Foods.fromJson(food))),
      drinks: List<Drinks>.from(
          json["drinks"].map((drink) => Drinks.fromJson(drink))));

  Map<String, dynamic> toJson() => {
        "foods": List<dynamic>.from(foods.map((food) => food.toJson())),
        "drinks": List<dynamic>.from(drinks.map((drink) => drink.toJson()))
      };
}

class Foods {
  late String name;

  Foods({required this.name});

  factory Foods.fromJson(Map<String, dynamic> json) =>
      Foods(name: json['name']);

  Map<String, dynamic> toJson() => {"name": name};
}

class Drinks {
  late String name;

  Drinks({required this.name});

  factory Drinks.fromJson(Map<String, dynamic> json) =>
      Drinks(name: json['name']);

  Map<String, dynamic> toJson() => {"name": name};
}
